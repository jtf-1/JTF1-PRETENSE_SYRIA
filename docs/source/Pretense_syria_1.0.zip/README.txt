Please see section 7. and 8. of the User Manual for instructions on how to properly set up persistence and multiplayer slotblocking.
User manual can be found here: https://github.com/Dzsek/pretense